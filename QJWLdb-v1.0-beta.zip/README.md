# 工程咨询全业务数据库平台 v1.0 Beta

一个完整的工程咨询全业务数据库管理系统，用于管理工程咨询行业的文件类型、关键信息字段、审计规则、法规标准等核心业务数据。

## 📋 项目概述

本系统以"工程咨询全业务数据库设计"为中心，提供统一的数据管理平台，支持：

- 工程全阶段文件体系管理
- 关键信息字段定义与提取规则
- 审计规则与逻辑管理
- 法律法规与标准库管理
- 文件模板/示例管理

## 🎯 核心功能模块

### 1. 文件类型管理

管理工程项目各阶段的文件类型，包括项目阶段、大类、小类等分类维度。

**主要功能：**
- 文件类型的增删改查、批量操作
- Excel 模板下载与批量导入
- 支持按项目阶段、大类、状态筛选
- 自动编码生成

### 2. 关键信息字段管理

定义每种文件类型中需要提取的关键信息字段。

**主要功能：**
- 字段与文件类型的关联管理
- 支持多种字段类别（金额、日期、数量、文字、枚举等）
- 定位词、枚举值、取值方式等配置
- 支持 LLM 提取描述配置

### 3. 审计规则管理

定义审计逻辑规则，支持关联关键信息字段和法规条款。

**主要功能：**
- 规则与数据源字段的关联（最多5个）
- 规则与法规条款的关联
- 审计类型、阶段、查证板块分类
- 自动编码生成（拼音首字母规则）

### 4. 法规与标准库

管理法律法规和标准文件。

**主要功能：**
- 法规文件管理
- 法规条款管理
- 条款与文件类型的适用关系

### 5. 文件模板/示例

存储各文件类型的示例文件，支持在线预览和下载。

## 🔢 编码规则详解

系统采用自动编码机制，确保各类数据的唯一标识。

### 文件类型编码

**格式：** `{项目阶段简码}{大类简码}{小类简码}{4位序号}`

**示例：** `QQTZ0101001`

**生成规则：**
1. 项目阶段简码（2位）：从枚举选项的 shortCode 获取（如"前期阶段"→"QQ"）
2. 大类简码（2位）：从枚举选项的 shortCode 获取（如"投资决策阶段"→"TZ"）
3. 小类简码（2位）：从枚举选项的 shortCode 获取（如"立项审批"→"01"）
4. 序号（4位）：同一分类下的自增序号（如"001"）

**枚举简码生成规则：**
- 汉字：取前两个字的拼音首字母大写（如"工程管理"→"GC"）
- 数字开头：直接使用前两位或补零（如"01"→"01"）

### 关键信息字段编码

**格式：** `{文件类型编码}-{3位序号}`

**示例：** `QQTZ0101001-001`

**生成规则：**
1. 取所属文件类型的编码
2. 添加3位自增序号

### 审计规则编码

**格式：** `{审计类型拼音2位}{阶段拼音2位}{查证板块拼音2位}{4位序号}`

**示例：** `GCZTJZ0001`

**生成规则：**
1. 审计类型（2位）：取前2个汉字的拼音首字母（如"工程管理审计"→"GC"）
2. 阶段（2位）：取前2个汉字的拼音首字母（如"招投标阶段"→"ZT"）
3. 查证板块（2位）：取前2个汉字的拼音首字母（如"造价核验"→"ZJ"）
4. 序号（4位）：同一分类下的自增序号

### 文件模板/示例编码

**格式：** `{文件类型编码}-{大写字母}`

**示例：** `QQTZ0101001-A`、`QQTZ0101001-B`

**生成规则：**
1. 取所属文件类型的编码
2. 添加大写字母序号（A、B、C...）

## 🏗 业务逻辑说明

### 文件类型与字段关系

```
文件类型 (1) ──── (*) 关键信息字段
         └──── (*) 文件模板/示例
```

- 一个文件类型可以有多个关键信息字段
- 一个文件类型可以有多个模板/示例文件
- 删除文件类型时，级联删除关联的字段和模板

### 审计规则与数据源关系

```
审计规则 ──── 数据源1-5编码 ──── 关键信息字段
         └── 法条编码 ──── 法规条款
```

- 审计规则最多可关联5个数据源（关键信息字段）
- 填入数据源编码后，自动带出对应的名称
- 可关联法规条款作为审计依据

### 法规与条款关系

```
法规文件 (1) ──── (*) 法规条款
法规条款 (*) ──── (*) 文件类型（适用关系）
```

### 枚举选项管理

系统使用动态枚举选项管理分类数据：

- **projectPhase**：项目阶段（如：前期阶段、施工阶段）
- **majorCategory**：大类（如：投资决策阶段、招标投标阶段）
- **minorCategory**：小类（如：立项审批、可行性研究）
- **projectType**：项目类型
- **region**：适用地区
- **ownerOrg**：适用业主
- **auditType**：审计类型
- **auditPhase**：审计阶段
- **verifySection**：查证板块

## 🛠 技术栈

### 后端
- **Node.js 18+ / TypeScript**
- **NestJS 10** - 企业级 Node.js 框架
- **TypeORM** - ORM 框架（支持自动迁移）
- **MySQL 8** - 数据库（字符集：utf8mb4_bin）
- **Swagger/OpenAPI** - API 文档
- **JWT** - 身份认证
- **ExcelJS** - Excel 导入导出
- **pinyin** - 拼音转换（用于自动编码）

### 前端
- **React 18 + TypeScript**
- **Vite** - 构建工具
- **shadcn/ui** - UI 组件库（基于 Radix UI）
- **Tailwind CSS** - 样式框架
- **Lucide React** - 图标库
- **React Query (TanStack Query)** - 数据请求状态管理
- **React Router 6** - 路由管理

### 开发原则
- 前端只使用 shadcn/ui + Tailwind CSS + Lucide React，不使用 AntD
- 资源配置集中管理（`/config/resources.ts`），修改字段只需改一处
- 后端采用模块化架构，每个业务模块独立

## 📁 项目结构

```
QJWLdb/
├── backend/                      # 后端项目
│   ├── src/
│   │   ├── common/              # 通用模块
│   │   │   ├── controllers/     # 通用控制器（枚举选项）
│   │   │   ├── dto/             # 通用DTO（分页、批量操作）
│   │   │   ├── entities/        # 基础实体
│   │   │   └── services/        # 通用服务（编码生成）
│   │   ├── modules/             # 业务模块
│   │   │   ├── auth/            # 认证模块
│   │   │   ├── doc-type/        # 文件类型
│   │   │   ├── doc-field-def/   # 关键信息字段
│   │   │   ├── doc-template-sample/ # 文件模板/示例
│   │   │   ├── audit-rule/      # 审计规则
│   │   │   ├── law-document/    # 法规与标准
│   │   │   ├── law-clause/      # 法规条款
│   │   │   └── file-upload/     # 文件上传
│   │   ├── app.module.ts
│   │   └── main.ts
│   └── package.json
│
├── frontend/                    # 前端项目
│   ├── src/
│   │   ├── components/
│   │   │   ├── resource/        # 资源管理组件（表格、表单、筛选等）
│   │   │   └── ui/              # shadcn/ui 组件
│   │   ├── config/
│   │   │   └── resources.ts     # 资源配置（列、表单、筛选器）
│   │   ├── layouts/             # 布局组件
│   │   ├── pages/               # 页面组件
│   │   ├── services/            # API 服务
│   │   ├── hooks/               # 自定义 Hooks
│   │   └── types/               # TypeScript 类型定义
│   └── package.json
│
├── project/
│   └── uploads/                 # 上传文件存储目录
│
├── docker-compose.yml           # Docker 编排
└── README.md
```

## 🚀 快速开始

### 前置要求
- Node.js >= 18
- MySQL >= 8.0
- Docker（可选，用于数据库）

### 1. 启动数据库

使用 Docker：
```bash
docker-compose up -d mysql
```

或手动创建数据库：
```sql
CREATE DATABASE qjwl_db CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
```

### 2. 配置后端

```bash
cd backend

# 复制环境配置
cp env.example .env

# 编辑 .env 文件，配置数据库连接
# DB_HOST=localhost
# DB_PORT=3306
# DB_USERNAME=root
# DB_PASSWORD=your_password
# DB_DATABASE=qjwl_db

# 安装依赖
npm install

# 启动开发服务器
npm run start:dev
```

后端服务启动后：
- API 服务：http://localhost:3000
- Swagger 文档：http://localhost:3000/api-docs
- 健康检查：http://localhost:3000/api/v1/healthz

### 3. 配置前端

```bash
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

前端服务启动后访问：http://localhost:5173

### 4. 初始化数据

首次启动后，建议执行以下初始化操作：

```bash
# 同步枚举选项（从现有文件类型数据）
curl -X POST http://localhost:3000/api/v1/doc-types/sync-enum-options \
  -H "Authorization: Bearer <token>"

# 生成枚举简码（用于自动编码）
curl -X POST http://localhost:3000/api/v1/enum-options/generate-short-codes \
  -H "Authorization: Bearer <token>"
```

## 🔐 认证说明

### 默认管理员账号
- 用户名：`admin`
- 密码：`admin123`

### 登录接口
```bash
POST /api/v1/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

### 使用 Token
在请求头中携带：
```
Authorization: Bearer <accessToken>
```

## 📖 API 接口概览

所有接口统一前缀：`/api/v1`

### 通用接口规范

| 操作 | 接口格式 | 说明 |
|------|----------|------|
| 列表 | GET /[resource]/list | 分页查询，支持 page、pageSize、keyword |
| 详情 | GET /[resource]/:id | 获取单条记录 |
| 创建 | POST /[resource] | 创建记录 |
| 更新 | PUT /[resource]/:id | 更新记录 |
| 删除 | DELETE /[resource]/:id | 删除记录 |
| 批量启用 | POST /[resource]/batch/enable | 批量启用 |
| 批量停用 | POST /[resource]/batch/disable | 批量停用 |
| 批量删除 | POST /[resource]/batch/delete | 批量删除 |
| 下载模板 | GET /[resource]/template | 下载 Excel 导入模板 |
| 导入 | POST /[resource]/import | Excel 批量导入 |
| 导出 | GET /[resource]/export | 导出 Excel |

### 主要资源路径

| 资源 | 路径 | 说明 |
|------|------|------|
| 文件类型 | /doc-types | 文件类型管理 |
| 关键信息字段 | /doc-field-defs | 关键信息字段管理 |
| 文件模板/示例 | /doc-template-samples | 模板示例管理 |
| 审计规则 | /audit-rules | 审计规则管理 |
| 法规与标准 | /law-documents | 法规文件管理 |
| 法规条款 | /law-clauses | 法规条款管理 |
| 枚举选项 | /enum-options | 枚举选项管理 |
| 文件上传 | /files | 文件上传下载 |

## 🗄 核心数据表结构

### doc_type（文件类型）

| 字段 | 类型 | 说明 |
|------|------|------|
| code | VARCHAR(50) | 编码（自动生成，唯一） |
| name | VARCHAR(100) | 名称 |
| project_phase | VARCHAR(50) | 项目阶段 |
| major_category | VARCHAR(100) | 大类 |
| minor_category | VARCHAR(100) | 小类 |
| file_feature | TEXT | 文件特征（LLM识别用） |
| project_type | VARCHAR(200) | 适用项目类型 |
| region | VARCHAR(100) | 适用地区 |
| owner_org | VARCHAR(200) | 适用业主 |
| biz_description | TEXT | 业务说明 |

### doc_field_def（关键信息字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| doc_type_id | BIGINT | 所属文件类型ID |
| field_code | VARCHAR(50) | 字段编码（自动生成） |
| field_name | VARCHAR(100) | 字段名称 |
| field_category | VARCHAR(50) | 字段类别 |
| required_flag | TINYINT | 是否必填 |
| value_source | TEXT | 取值方式 |
| value_source_llm | TEXT | 提取方式-LLM用 |
| anchor_word | TEXT | 定位词 |
| enum_options | TEXT | 枚举值 |
| example_value | TEXT | 示例数据 |
| field_description | TEXT | 字段说明 |
| process_method | VARCHAR(100) | 处理方式 |

### audit_rule（审计规则）

| 字段 | 类型 | 说明 |
|------|------|------|
| rule_code | VARCHAR(50) | 规则编码（自动生成） |
| rule_name | VARCHAR(200) | 规则名称 |
| audit_type | VARCHAR(50) | 审计类型 |
| phase | VARCHAR(50) | 阶段 |
| verify_section | VARCHAR(50) | 查证板块 |
| problem_desc | TEXT | 问题描述 |
| compare_method | TEXT | 比对方式 |
| compare_method_llm | TEXT | 比对方式-LLM用 |
| audit_basis | TEXT | 审计依据内容 |
| source1_code ~ source5_code | VARCHAR(50) | 数据源1-5编码 |
| source1_name ~ source5_name | VARCHAR(100) | 数据源1-5名称 |
| law_clause_code | VARCHAR(50) | 法条编码 |

### enum_option（枚举选项）

| 字段 | 类型 | 说明 |
|------|------|------|
| category | VARCHAR(50) | 分类（如projectPhase） |
| value | VARCHAR(200) | 选项值 |
| short_code | VARCHAR(10) | 简码（用于编码生成） |
| parent_value | VARCHAR(200) | 父选项值（用于级联） |
| sort_order | INT | 排序 |

## 🐳 Docker 部署

```bash
# 启动所有服务
docker-compose up -d

# 仅启动数据库
docker-compose up -d mysql

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 🔧 开发说明

### 添加新资源

1. **后端**：在 `backend/src/modules/` 创建模块
   - 创建 Entity、DTO、Service、Controller、Module
   - 在 `app.module.ts` 注册模块

2. **前端**：
   - 在 `frontend/src/config/resources.ts` 添加资源配置
   - 在 `frontend/src/pages/resources/` 创建页面组件
   - 在 `frontend/src/App.tsx` 添加路由

### 修改资源字段

只需修改 `frontend/src/config/resources.ts` 中的配置：
- `columns`：表格列配置
- `formFields`：表单字段配置
- `filters`：筛选器配置

### 代码规范

- 后端使用 NestJS 模块化结构
- 前端使用 React Query 管理服务端状态
- 所有实体继承 BaseEntity（含 id, status, createdAt, updatedAt）
- API 路径使用小写和连字符

## 📝 版本历史

### v1.0 Beta (2026-01-26)
- ✅ 完整的文件类型管理
- ✅ 关键信息字段管理（含 LLM 提取配置）
- ✅ 审计规则管理（含数据源关联）
- ✅ 法规与标准库管理
- ✅ 文件模板/示例管理
- ✅ 自动编码生成（拼音首字母规则）
- ✅ Excel 导入导出
- ✅ 批量操作
- ✅ 现代化 UI（shadcn/ui + Tailwind）

## 📝 License

MIT
